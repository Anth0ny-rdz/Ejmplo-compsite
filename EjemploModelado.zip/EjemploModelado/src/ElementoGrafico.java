public interface ElementoGrafico {

     void dibujar();
}
