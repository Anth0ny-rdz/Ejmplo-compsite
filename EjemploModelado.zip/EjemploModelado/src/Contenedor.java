public class Contenedor implements ElementoGrafico{
    @Override
    public void dibujar() {
        System.out.println("Dibujando Contenedor");
    }
}
