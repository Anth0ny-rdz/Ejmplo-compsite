public class CampoDeTexto implements ElementoGrafico{
    @Override
    public void dibujar() {
        System.out.println("Dibujando campo de texto");
    }
}
