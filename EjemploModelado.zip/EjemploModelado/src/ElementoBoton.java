import java.util.function.Consumer;

public interface ElementoBoton extends ElementoGrafico{

    public <T> void click(Consumer<T>consumer);

     int getColor();


}
