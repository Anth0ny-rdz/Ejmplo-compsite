public class Main {
    public static void main(String[] args) {
        ElementoBoton boton = new Boton();
        ElementoGrafico campoDeTexto=new CampoDeTexto();
        ElementoGrafico contendor=new Contenedor();
        contendor.dibujar();
        boton.dibujar();
        boton.click(o -> {
            System.out.println("El boton se ha clickeado");
        });
        System.out.println(boton.getColor());
        
        campoDeTexto.dibujar();

    }
}
